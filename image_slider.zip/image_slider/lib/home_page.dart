import 'package:card_swiper/card_swiper.dart';
import 'package:flutter/material.dart';
import 'package:image_slider/modal/imagepath.dart';

class MyHomePage extends StatelessWidget {
  final String title;

  const MyHomePage({super.key, required this.title});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(title),
      ),
      body: SingleChildScrollView(
          child:
              CardLayout()),
    );
  }
}

class CardLayout extends StatelessWidget {
  const CardLayout({
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
        width: MediaQuery.of(context).size.width,
        height: 400,
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.only(
              bottomLeft: Radius.circular(35),
              bottomRight: Radius.circular(35)),
        ),
        child: Column(children: [
          SwiperBuilder(),
        ]));
  }
}

class SwiperBuilder extends StatelessWidget {
  const SwiperBuilder({
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.all(10),
      child: ClipRRect(
    borderRadius: BorderRadius.only(
        bottomLeft: Radius.circular(25), bottomRight: Radius.circular(25)),
    child: Swiper(
      itemWidth: 400,
      loop: true,
      duration: 1200,
      scrollDirection: Axis.horizontal,
      itemHeight: 225,
      layout: SwiperLayout.STACK,
      itemCount: imagepath.length,
      itemBuilder: (BuildContext context, int index) {
        return Container(
          width: 400,
          height: 400,
          decoration: BoxDecoration(
            image: DecorationImage(
              image: NetworkImage(imagepath[index]),
            ),
            borderRadius: BorderRadius.circular(25),
          ),
        );
      },
    ),
      ),
    );
  }
}
